"""
Integration Tests

Tests for component interactions and system integration.
"""
